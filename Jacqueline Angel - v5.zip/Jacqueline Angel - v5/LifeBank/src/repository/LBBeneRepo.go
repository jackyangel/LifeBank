package repository

import (
	"log"

	"github.com/LifeBank/src/model/entity"
)

func SaveBenefi(b *entity.BeneficiaryEntity) (err error) {

	db, err := GetDBConnection()
	if err != nil {
		log.Fatal(err.Error())
		panic("Falló la conexión")
		return
	}
	defer db.Close()

	insItem := entity.BeneficiaryEntity{}

	err = db.Create(b).Scan(&insItem).Error
	if err != nil {
		return
	}

	return
}

func ValidateAccBeneficiary(account string, typePro string) int {

	db, err := GetDBConnection()
	if err != nil {
		log.Fatal(err.Error())
		panic("Falló la conexión")
		return 0
	}
	defer db.Close()
	var count int
	db.Table("accounts").Select("accounts.id_client").
		Joins("inner join products on accounts.product = products.id").
		Where("accounts.id_account = ? and products.name = ?", account, typePro).Count(&count)

	return count

}

func AlredyExistBen(account string) bool {

	db, err := GetDBConnection()
	if err != nil {
		log.Fatal(err.Error())
		panic("Falló la conexión")
		return true
	}
	defer db.Close()

	var count int
	users := &entity.BeneficiaryEntity{}

	db.Where("account = ?", account).Find(&users).Count(&count)

	if count > 0 {
		return true
	}
	return false

}
