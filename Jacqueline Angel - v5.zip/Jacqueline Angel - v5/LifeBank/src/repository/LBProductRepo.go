package repository

import (
	"database/sql"
	"log"
)

func GetListPro(cli int) (rw *sql.Rows, err error) {

	db, err := GetDBConnection()
	if err != nil {
		log.Fatal(err.Error())
		panic("Falló la conexión")
		return
	}
	defer db.Close()

	rw, err = db.Table("accounts").Select("products.name, accounts.id_account, accounts.description").
		Joins("inner join client on client.id_client = accounts.id_client").
		Joins("inner join products on accounts.product = products.id").
		Where("accounts.id_client = ?", cli).Rows()
	return

}
