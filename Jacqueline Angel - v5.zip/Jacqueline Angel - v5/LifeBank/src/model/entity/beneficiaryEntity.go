package entity

import "time"

type BeneficiaryEntity struct {
	IdBen      int       `gorm:"PRIMARY_KEY; AUTO_INCREMENT"`
	Account    string    `gorm:"type:varchar(50); not null"`
	Name       string    `gorm:"type:varchar(50); not null"`
	Email      string    `gorm:"type:varchar(50); not null"`
	AfBy       int       `gorm:"type:varchar(50); not null"`
	created_at time.Time `gorm:"type:timestamp"`
	updated_at time.Time `gorm:"type:timestamp"`
}

func (u *BeneficiaryEntity) TableName() string {
	return "BENEFICIARIES"
}
