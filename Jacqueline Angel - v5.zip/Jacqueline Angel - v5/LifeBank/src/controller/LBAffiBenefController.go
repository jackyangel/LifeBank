package controllers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"

	"github.com/LifeBank/src/model/request"
	"github.com/LifeBank/src/process"
)

func AffiBeneController(w http.ResponseWriter, r *http.Request) {

	//Obtiene el mensaje de petición
	var request request.LBAffiBeneficiaryReq
	err := json.NewDecoder(r.Body).Decode(&request)
	if err != nil {
		fmt.Println(err.Error())
	}

	auth := strings.SplitN(r.Header.Get("Authorization"), " ", 2)
	tknStr := auth[1]

	httpCode := process.AffiBeneficiaryy(tknStr, request)
	if httpCode != http.StatusOK {
		w.WriteHeader(httpCode)
		return
	}

	w.WriteHeader(http.StatusCreated)
}
