package process

import (
	"log"
	"net/http"

	r "github.com/LifeBank/src/model/response"
	"github.com/LifeBank/src/repository"
	"github.com/LifeBank/src/utils"
)

func ListProducts(tknStr string) (httpCode int, json r.ListProductsRes) {

	client, httpCode := utils.ValidateToken(tknStr)
	if httpCode != http.StatusOK {
		return
	}

	json, err := GetListProducts(client)
	if err != nil {
		log.Println(": Ocurrio un Error obteniendo la lista de productos")
		httpCode = http.StatusBadRequest
	}

	httpCode = http.StatusOK
	return
}

func GetListProducts(cli int) (lsProducts r.ListProductsRes, err error) {

	rows, err := repository.GetListPro(cli)
	if err != nil {
		return
	}

	listP := make(map[string][]r.Product)

	var product, id, name string

	for rows.Next() {
		rows.Scan(&product, &id, &name)
		listP[product] = append(listP[product], r.Product{id, name})
	}
	lsProducts = r.ListProductsRes{Accounts: listP}

	return
}
