package process

import (
	"log"
	"net/http"
	"regexp"

	"github.com/LifeBank/src/repository"

	"github.com/LifeBank/src/model/entity"
	req "github.com/LifeBank/src/model/request"
	"github.com/LifeBank/src/utils"
)

func AffiBeneficiaryy(tknStr string, request req.LBAffiBeneficiaryReq) (httpCode int) {

	client, httpCode := utils.ValidateToken(tknStr)
	if httpCode != http.StatusOK {
		return
	}

	httpCode = SaveBeneficiary(client, request)
	if httpCode != http.StatusOK {
		return
	}

	httpCode = http.StatusOK
	return
}

func SaveBeneficiary(cli int, request req.LBAffiBeneficiaryReq) (httpCode int) {

	exist := repository.ValidateAccBeneficiary(request.Account, request.Atype)

	if exist != 1 {
		log.Println(": La cuenta del Beneficiario no existe o tipo de cuenta no es la correcta")
		httpCode = http.StatusNotFound
		return
	}
	if !ValidateEmail(request.Email) {
		log.Println(": Email inválido")
		httpCode = http.StatusBadRequest
		return
	}

	if repository.AlredyExistBen(request.Account) {
		log.Println(": El Beneficiario ya se ha afiliado")
		httpCode = http.StatusConflict
		return
	}

	ben := &entity.BeneficiaryEntity{
		Account: request.Account,
		Name:    request.Name,
		Email:   request.Email,
		AfBy:    cli,
	}

	repository.SaveBenefi(ben)

	httpCode = http.StatusOK
	return
}

func ValidateEmail(email string) bool {
	Re := regexp.MustCompile(`^[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,4}$`)
	return Re.MatchString(email)
}
