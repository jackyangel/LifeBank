package main

import (
	"log"

	handler "github.com/LifeBank/src/handler"
)

func init() {
	log.SetPrefix("LOG: ")
	log.SetFlags(log.Ldate | log.Lmicroseconds)
}

func main() {
	handler.StartServer()
}
