package utils

import (
	"log"
	"net/http"
	"time"

	"github.com/dgrijalva/jwt-go"
)

var jwtKey = []byte("p9f1z8L175KTLNSHVXgtgie9Wts5-xJl1vi1BLTvI0SyUBXhgTPLfctpgG-vW13OqmAex-MiBZ2_PaT6M_a-cw")

type Claims struct {
	IdAccount int    `json:"IdUser"`
	IpAddress string `json:"IpAddress"`
	jwt.StandardClaims
}

func Generatejwt(client int, ip string) (string, error) {

	expirationTime := time.Now().Add(30 * time.Minute)
	claims := &Claims{
		IdAccount: client,
		IpAddress: ip,
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: expirationTime.Unix(),
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS512, claims)
	tokenString, err := token.SignedString(jwtKey)
	if err != nil {
		log.Println(err.Error())
		return "", err
	}
	return tokenString, nil
}

func ValidateToken(tknStr string) (client int, httpCode int) {
	claims := &Claims{}
	tkn, err := jwt.ParseWithClaims(tknStr, claims, func(token *jwt.Token) (interface{}, error) {
		return jwtKey, nil
	})
	client = claims.IdAccount

	if !tkn.Valid {
		log.Println(": Tiempo del token a expirado")
		httpCode = http.StatusUnauthorized
		return
	}

	if err != nil {
		if err == jwt.ErrSignatureInvalid {
			log.Println(": firma invalida")
			httpCode = http.StatusUnauthorized
			return
		}
		log.Println(": ocurrio un error")
		httpCode = http.StatusBadRequest
		return
	}
	httpCode = http.StatusOK
	return
}
