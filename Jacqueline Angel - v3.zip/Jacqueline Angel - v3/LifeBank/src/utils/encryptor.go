package utils

import (
	"crypto/sha512"
	b64 "encoding/base64"
	"fmt"
	"strings"
)

func CodePass(user string, pass string) string {
	// base64(nombre)
	nameEnc := b64.StdEncoding.EncodeToString([]byte(user))

	// base64(contraseña)
	passEnc := b64.StdEncoding.EncodeToString([]byte(pass))

	s := []string{nameEnc, passEnc}

	input := strings.Join(s, "")

	sha_512 := sha512.New()
	sha_512.Write([]byte(input))

	encryptedpass := fmt.Sprintf("%x", sha_512.Sum(nil))

	return encryptedpass
}
