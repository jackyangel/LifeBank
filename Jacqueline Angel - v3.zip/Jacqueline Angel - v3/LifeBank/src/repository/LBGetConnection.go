package repository

import (
	"github.com/LifeBank/src/resources"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/mysql"
)

func GetDBConnection() (database *gorm.DB, err error) {

	cfg, _ := resources.GetConfig()
	dbDriver, _ := cfg.String("datasource.platform")
	dbUser, _ := cfg.String("datasource.username")
	dbPass, _ := cfg.String("datasource.password")
	dbUrl, _ := cfg.String("datasource.url")

	database, err = gorm.Open(dbDriver, dbUser+":"+dbPass+dbUrl+"?parseTime=true")
	return
}
