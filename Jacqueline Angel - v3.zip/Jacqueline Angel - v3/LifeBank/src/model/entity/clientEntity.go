package entity

import "time"

type LBClientEntity struct {
	IdClient  int       `gorm:"PRIMARY_KEY; AUTO_INCREMENT"`
	Name      string    `gorm:"type:varchar(50)"`
	Lastname  string    `gorm:"type:varchar(50)"`
	Document  string    `gorm:"type:varchar(9)"`
	Phone     string    `gorm:"type:varchar(50)"`
	Email     string    `gorm:"type:varchar(50)"`
	CreatedAt time.Time `gorm:"type:timestamp"`
	UpdatedAt time.Time `gorm:"type:timestamp"`
}

func (u *LBClientEntity) TableName() string {
	return "CLIENT"
}
