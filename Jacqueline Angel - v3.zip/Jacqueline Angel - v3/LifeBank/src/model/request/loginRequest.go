package request

type LBLoginRequest struct {
	User     string `json:"user"`
	Password string `json:"password"`
}
