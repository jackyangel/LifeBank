create database lifebank
use lifebank
create table client (
  id_client int not null primary key auto_increment,
  name varchar(50) default null,
  lastname varchar(50) default null,
  document varchar(9) default null,
  phone varchar(50) default null,
  email varchar(50) default null,
  created_at timestamp not null default current_timestamp on update current_timestamp,
  updated_at timestamp not null default '0000-00-00 00:00:00'
)

create table users (
  name_user varchar(10) not null primary key, 
  id_client int not null,
  password varchar(255) not null,
  num_attemps int default null,
  locked int default null,
  created_at timestamp not null default current_timestamp on update current_timestamp,
  updated_at timestamp not null default '0000-00-00 00:00:00',
  constraint usercli foreign key (id_client) references client(id_client)
) 

create table products (
  id int not null auto_increment primary key,
  name varchar(50),
  created_at timestamp not null default current_timestamp on update current_timestamp,
  updated_at timestamp not null default '0000-00-00 00:00:00'
)

create table accounts (
  id_account varchar(8) not null primary key,
  id_client int not null,
  product int not null,
  description varchar(100),
  created_at timestamp not null default current_timestamp on update current_timestamp,
  updated_at timestamp not null default '0000-00-00 00:00:00',
  constraint acclien foreign key (id_client) references client(id_client),
  constraint accpro foreign key (product) references products(id)
)

create table account_details(
	account varchar(8) not null,
	amount double(8,2),
	total double(8,2),
	debt double(8,2),
	creditlimit double(8,2),
	available double(8,2),
	interestRate double(8,2),
	interestAmount double(8,2),
	MonthlyCut timestamp default '0000-00-00 00:00:00',
	constraint creditacc foreign key (account) references accounts(id_account)
)

create table transactions(
it_transac int not null auto_increment primary key,
account varchar(8) not null,
auth_num varchar(8) not null,
amount double(8,2) not null,
d_account varchar(8) not null,
created_at timestamp not null default current_timestamp on update current_timestamp,
updated_at timestamp not null default '0000-00-00 00:00:00',
constraint transac foreign key (account) references accounts(id_account)
)

create table beneficiaries(
id_ben int not null auto_increment primary key,
account varchar(8) not null,
name varchar(50) not null,
email varchar(50) not null,
af_by int not null,
created_at timestamp not null default current_timestamp on update current_timestamp,
updated_at timestamp not null default '0000-00-00 00:00:00',
constraint af_by_cl foreign key (af_by) references client(id_client)
)

INSERT INTO `client` (`id_client`, `name`, `lastname`, `document`, `phone`, `email`, `created_at`, `updated_at`) VALUES
(1, 'Jacquelin', 'Angel', '123456789', '1234567', 'jgangelc@gmail.com', '2019-05-12 13:17:37', '2019-05-12 13:17:37'),
(2, 'Ana', 'Mozz', '123456733', '78654321', 'annamozz@gmail.com', '2019-05-12 13:17:38', '2019-05-12 13:17:38'),
(3, 'Karla', 'Gomez', '383049203', '77777789', 'karla@outlook.com', '2019-05-12 06:58:04', '0000-00-00 00:00:00'),
(4, 'Alvaro', 'Morales', '057493845', '73549237', 'alvarom@gmail.com', '2019-05-12 06:58:57', '0000-00-00 00:00:00');

INSERT INTO `users` (`name_user`, `id_client`, `password`, `num_attemps`, `locked`, `created_at`, `updated_at`) VALUES
('anna', 2, '6f56b0f81126e287a872ab734431da3fbbf5c7acaf0dfd3308b3ba7c7e4492a9812ec42a5165ec8f32da8fe08cb14c1dfae2bc9a00f029113e4b108228704f2c', 0, 0, '2019-05-12 07:17:38', '2019-05-12 07:17:38'),
('jacky', 1, '794c2d6c597de4e993829557653e02df4889bef52cc07d35ce364d7b6d789956a8cbbdc6b81a71a36ae5473ba0c98f94dfebf3e438a282cd2af2283d829d56d5', 0, 0, '2019-05-12 01:18:19', '2019-05-12 07:18:19');

INSERT INTO `products` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Credit Card', '2019-05-12 06:53:24', '0000-00-00 00:00:00'),
(2, 'Loan', '2019-05-12 06:53:24', '0000-00-00 00:00:00'),
(3, 'Personal', '2019-05-12 06:53:24', '0000-00-00 00:00:00');

INSERT INTO `accounts` (`id_account`, `id_client`, `product`, `description`, `created_at`, `updated_at`) VALUES
('12345678', 1, 2, 'University Loan', '2019-05-12 06:55:35', '0000-00-00 00:00:00'),
('12345679', 1, 3, 'Savings account', '2019-05-12 06:55:35', '0000-00-00 00:00:00'),
('12345690', 1, 1, 'Platinum credit card', '2019-05-12 06:55:35', '0000-00-00 00:00:00'),
('27638495', 2, 1, 'Classic credit card', '2019-05-12 06:56:28', '0000-00-00 00:00:00'),
('87637849', 2, 1, 'Platinum credit card', '2019-05-12 06:56:28', '0000-00-00 00:00:00'),
('90764527', 3, 2, 'mortgage loan', '2019-05-12 07:01:18', '0000-00-00 00:00:00'),
('94848583', 4, 1, 'Classic credit card', '2019-05-12 07:01:17', '0000-00-00 00:00:00'),
('98473647', 2, 3, 'Savings account', '2019-05-12 06:56:29', '0000-00-00 00:00:00');

INSERT INTO `account_details` (`account`, `amount`, `total`, `debt`, `creditlimit`, `available`, `interestRate`, `interestAmount`, `MonthlyCut`) VALUES
('12345678', NULL, 1000.00, 600.00, NULL, NULL, 0.50, 100.00, '0000-00-00 00:00:00'),
('12345679', 3000.00, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00');




