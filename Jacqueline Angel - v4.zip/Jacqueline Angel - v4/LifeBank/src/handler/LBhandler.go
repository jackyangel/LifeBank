package handler

import (
	"log"
	"net/http"

	controllers "github.com/LifeBank/src/controller"
	"github.com/LifeBank/src/resources"
	"github.com/gorilla/mux"
)

func StartServer() {

	cfg, _ := resources.GetConfig()

	port, _ := cfg.String("server.port")

	// Iniciando ruteo
	r := mux.NewRouter()

	r.HandleFunc("/SignIn", controllers.SignInController).Methods("POST")
	r.HandleFunc("/Myproducts", controllers.ProductsController).Methods("GET")
	r.HandleFunc("/AfBeneficiary", controllers.AffiBeneController).Methods("POST")
	log.Println(": Starting server...")
	// Iniciando servidor
	http.ListenAndServe(port, r)
}
