package controllers

import (
	"encoding/json"
	"log"
	"net/http"

	"github.com/LifeBank/src/model/request"
	"github.com/LifeBank/src/process"
	"github.com/LifeBank/src/utils"
)

func SignInController(w http.ResponseWriter, r *http.Request) {
	//Obtiene el mensaje de petición
	var request request.LBLoginRequest
	err := json.NewDecoder(r.Body).Decode(&request)
	if err != nil {
		log.Println(err.Error())
	}

	ip := utils.GetIPAdress(r)

	httpCode, tknrespose := process.Authentication(request, ip)

	if httpCode != http.StatusOK {
		w.WriteHeader(httpCode)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(tknrespose)

}
