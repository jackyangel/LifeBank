package entity

import "time"

type LBUserEntity struct {
	NameUser   string `gorm:"PRIMARY_KEY"`
	IdClient   int
	Password   string
	NumAttemps int
	Locked     int
	CreatedAt  time.Time `gorm:"type:timestamp"`
	UpdatedAt  time.Time `gorm:"type:timestamp"`
}

type LBUserFKEntity struct {
	NameUser   string         `gorm:"PRIMARY_KEY"`
	Client     LBClientEntity `gorm:"foreignkey:IdClient"`
	Password   string
	NumAttemps int
	Locked     int
	CreatedAt  time.Time `gorm:"type:timestamp"`
	UpdatedAt  time.Time `gorm:"type:timestamp"`
}

func (u *LBUserEntity) TableName() string {
	return "USERS"
}
