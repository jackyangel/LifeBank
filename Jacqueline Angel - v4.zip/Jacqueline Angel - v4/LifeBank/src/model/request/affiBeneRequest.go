package request

type LBAffiBeneficiaryReq struct {
	Account string `json:"Account"`
	Name    string `json:"Name"`
	Atype   string `json:"Type"`
	Email   string `json:"Email"`
}
